<?php

/*
  service.php

  Simple PHP service for a phone exercies

  Calls:
  http://localhost/prod-app/inc/service.php?typ=get-marken
  http://localhost/prod-app/inc/service.php?typ=search-marke&urval=Alla
  http://localhost/prod-app/inc/service.php?typ=search-marke&urval=Apple
  http://localhost/prod-app/inc/service.php?typ=get-product&id=102

 */

date_default_timezone_set("Europe/Stockholm");

// Load the phone data
$jsonString = file_get_contents("http://localhost/prod-app/inc/phone-list.json");
$phones = json_decode($jsonString);

$method = $_SERVER['REQUEST_METHOD'];
if ($method == 'GET') {
    if (!isset($_GET['typ'])) {
        die('NOT TYPE SPECIFIED TYP');
    }
    $typ = $_GET['typ'];
    switch ($typ) {

        case 'get-marken':
            $result = getMarken($phones);
            echo json_encode($result);
            break;

        case 'search-marke':
            $urval = $_GET['urval'];
            $result = searchOnMarken($urval, $phones);
            echo json_encode($result);
            break;

        case 'get-product':
            $id = $_GET['id'];
            $result = getProduct($id, $phones);
            echo json_encode($result);
            break;
        case 'get-products':
            $ids = $_GET['ids'];
            $result = getProducts($ids, $phones);
            echo json_encode($result);
            break;
        default:
            break;
    }
} else if ($method == 'POST') {
    die('NOT ALLOWED METHOD');
} else {
    die('NOT ALLOWED METHOD');
}

/**
 * 
 * @param type $phones
 * @return array
 */
function getMarken($phones) {
    $result = [];
    foreach ($phones as $phone) {
        $new = new StdClass();
        $new->marke = $phone->marke;
        array_push($result, $new);
    }
    return $result;
}

/**
 * 
 * @param type $urval
 * @param type $phones
 * @return array
 */
function searchOnMarken($urval, $phones) {
    $result = [];
    if ($urval == "Alla") {
        foreach ($phones as $phone) {
            $new = new StdClass();
            $new->model = $phone->model;
            $new->pris = $phone->pris;
            $new->id = $phone->id;
            array_push($result, $new);
        }
    }
    foreach ($phones as $phone) {
        if ($phone->marke == $urval) {
            $new = new StdClass();
            $new->model = $phone->model;
            $new->pris = $phone->pris;
            $new->id = $phone->id;
            array_push($result, $new);
        }
    }
    return $result;
}

/**
 * 
 * @param type $urval
 * @param type $phones
 * @return array
 */
function getMarke($urval, $phones) {
    $result = [];
    foreach ($phones as $phone) {
        if ($phone->marke == $urval) {
            $new = new StdClass();
            $new->model = $phone->model;
            $new->pris = $phone->pris;
            array_push($result, $new);
        }
    }
    return $result;
}

/**
 * 
 * @param type $id
 * @param type $phones
 * @return \StdClass
 */
function getProduct($id, $phones) {
    $product = new StdClass();
    foreach ($phones as $phone) {
        if ($phone->id == $id) {
            $product->id = $phone->id;
            $product->model = $phone->model;
            $product->pris = $phone->pris;
            $product->marke = $phone->marke;
            $product->storlek = $phone->storlek;
            $product->os = $phone->os;
            $product->pixels = $phone->pixels;
            break;
        }
    }
    return $product;
}

function getProducts($ids, $phones) {

    $idSelected = utf8_decode(urldecode($ids));
    $result = [];
    foreach ($phones as $phone) {
        if (strpos($idSelected, $phone->id) !== false) {
            $new = new StdClass();
            $new->model = $phone->model;
            $new->pris = $phone->pris;
            $new->id = $phone->id;
            array_push($result, $new);
        }
    }
    return $result;
}
