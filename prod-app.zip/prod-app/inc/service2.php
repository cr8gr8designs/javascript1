<?php

/*
  service2.php
 */
date_default_timezone_set("Europe/Stockholm");
//define('URL',  'http://localhost/ec-js/api/');
define('URL', 'https://bappnet.se/eapi/');

$method = $_SERVER['REQUEST_METHOD'];
if ($method == 'GET') {
    if (isset($_GET['_action']) == false) {
        die('NOT TYPE SPECIFIED TYP');
    }
    $json = json_encode($_GET);
} else if ($method == 'POST') {
    $json = file_get_contents('php://input');
}
$curl = curl_init(URL);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Content-Length: ' . strlen($json))
);
$result = curl_exec($curl);
curl_close($curl);
echo($result);