
/**
 * 
 * @type type
 */
var Helper = {};

/**
 * 
 * @param {type} tag
 * @returns {undefined}
 */
Helper.show = function (tag) {
    document.getElementById(tag).style.display="block";
};

/**
 * 
 * @param {String} tag
 * @returns {undefined}
 */
Helper.showFlex = function (tag) {
    document.getElementById(tag).style.display="flex";
};

/**
 * 
 * @param {String} tag
 * @returns {undefined}
 */
Helper.hide = function (tag) {
    document.getElementById(tag).style.display="none";
};

/**
 * 
 * @param {String} tag
 * @param {type} value
 * @returns {undefined}
 */
Helper.setValue = function (tag, value) {
    document.getElementById(tag).value = value;
}

/**
 * 
 * @param {String} tag
 * @returns {Element.value}
 */
Helper.getValue = function (tag) {
    return document.getElementById(tag).value;
}

/**
 * 
 * @param {String} tag
 * @param {String} html
 * @returns {undefined}
 */
Helper.setHtml = function (tag, html) {
    document.getElementById(tag).innerHTML = html;
}

/**
 * 
 * @param {type} tag
 * @returns {String}
 */
Helper.getHtml = function (tag) {
    return document.getElementById(tag).innerHTML;
};

/**
 * 
 * @param {type} tag
 * @param {type} action
 * @returns {undefined}
 */
Helper.onClick = function (tag, action) {
    document.getElementById(tag).addEventListener("click", action);
};

/**
 * 
 * @param {type} tag
 * @param {type} event
 * @param {type} callback
 * @returns {undefined}
 */
Helper.on = function(tag, event, callback) {
    document.getElementById(tag).addEventlistener(event, callback);
};

/**
 * 
 * @param {type} class_name
 * @param {type} action
 * @returns {undefined}
 */
Helper.onClassClick = function (class_name, action) {
     var classes = document.getElementsByClassName(class_name);
     for (var i = 0; i < classes.length; ++i) {
         classes[i].addEventListener("click", action);
     }
};

/**
 * 
 * @param {type} tag
 * @returns {Element}
 */
Helper.get = function(tag) {
    return document.querySelector(tag);
};