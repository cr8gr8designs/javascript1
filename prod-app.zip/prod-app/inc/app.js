/**
 * @name Product App
 * @author Daniel Karjanlahti <dok.cr8gr8designs@gmail.com>
 * @version 1.0.0
 * @description Script for product application
 * 
 */

/**
 * Display selected brands
 * @returns {undefined}
 */
function searchProduct() {
    let brands = '';
    let brandsSelected = document.getElementById('select-marke');

    /**
     * Create URL parameter String for selected brands
     */
    for (let i = 0; i < brandsSelected.options.length; i++) {
        if (brandsSelected.options[i].selected) {
            brands += "'" + brandsSelected.options[i].value + "',";
        }
    }

    /**
     * If any brands were selected...
     */
    if (brands) {
        brands = brands.substring(0, brands.length - 1);


        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                let productObj = JSON.parse(this.responseText);
                let html = '<table>';
                for (let i = 0; i < productObj.length; i++) {
                    html += '<tr>';
                    html += '<td>' + productObj[i].model + '</td>';
                    html += '<td>' + productObj[i].price + '</td>';
                    html += '<td><input type="checkbox" class="compare-list" id="' + productObj[i].phone_id + '"/></td>';
                    html += '</tr>';
                }
                html += '</table>';
                Helper.setHtml('result-data', html);
                Helper.hide('search-container');
                Helper.show('result-container');

                /**
                 * Listen for checked input[type=checkbox] && class=compare-list
                 */
                Helper.onClassClick('compare-list', function () {
                    let checkboxes = document.getElementsByClassName('compare-list');
                    let ticked = 0;
                    for (let j = 0; j < checkboxes.length; j++) {
                        if (checkboxes[j].checked) {
                            ticked++;
                        }
                    }
                    /**
                     * If 4 checked checkboxes, then don't let user check any more
                     */
                    if (ticked === 5) {
                        this.checked = false;
                    }
                });
            }
        }

        xhttp.open("GET", "inc/service2.php?_action=ProductInBrandList&_brands=" + brands, true);
        xhttp.send();
    } else {
        return false;
    }

}

/**
 * Display selected models for comparison
 * @returns {undefined}
 */
function compareProduct() {
    let compareList = document.getElementsByClassName("compare-list"), ids = [], selectedIds = '';

    for (let i = 0; i < compareList.length; ++i) {
        if (compareList[i].checked) {
            ids.push(compareList[i].id);
        }
    }
    if (ids) {
        /**
         * Create URL parameter String
         */
        for (let j = 0; j < ids.length; j++) {
            (ids.length -1 !== j ? selectedIds += ids[j] + ',': selectedIds += ids[j]);
        }

        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                let productObj = JSON.parse(this.responseText);
                
                /**
                 * Create X number of forms with selected models
                 * @type String
                 */
                let html = '';
                for (let i = 0; i < productObj.length; i++) {
                    html += '<form class="product">';
                    html += '<div>Model: ' + productObj[i].model + '</div>';
                    html += '<div>Price: ' + productObj[i].price + '</div>';
                    html += '<div>Size: ' + productObj[i].size + '</div>';
                    html += '<div>Pixels: ' + productObj[i].pixels + '</div>';
                    html += '<div>OS: ' + productObj[i].os + '</div>';
                    html += '<div>Rating: ';
                    if (productObj[i].rating == 0) {
                        // If no rating...
                        html += '[No rating]';
                    } else {
                        // Display as many stars as set rating
                        for (let j = 0; j < productObj[i].rating; j++) {
                            html += '<span class="fa fa-star gold"></span>';
                        }
                    }

                    html += '</div>';
                    html += '<button type="button" class="btn btn-primary rate-product" id="' + productObj[i].phone_id + '" data-model="' + productObj[i].model + '">Rate product</button>';
                    html += '</form>';
                }

                /**
                 * Display container with selected models to be compared
                 */
                Helper.setHtml('compare-container', html);
                Helper.showFlex('compare-container');

                /**
                 * Hide search- & result- container
                 */
                Helper.hide('search-container');
                Helper.hide('result-container');

                /**
                 * Open rating/comment modal if Rate button is clicked
                 */
                Helper.onClassClick('rate-product', function () {
                    openModal(this.id, this.dataset.model);
                });
            }
        };

        xhttp.open("GET", "inc/service2.php?_action=PhoneCompareList&_ids=" + selectedIds, true);
        xhttp.send();

        //-> console.log('-----------------');
    } else {
        /**
         * No models checked
         * @returns false
         */
        return false;
    }

}

/**
 * Open rating/comment modal
 * @param {Int} phoneId
 * @param {String} phoneModel
 * @returns {undefined}
 */
function openModal(phoneId, phoneModel) {
    /**
     * Set modal heading as the model to give rating for
     */
    Helper.setHtml('rate-heading', phoneModel);

    let ratingComment = document.getElementById('rate-comment');

    /**
     * Show modal
     */
    Helper.showFlex('rating-modal');

    /**
     * Close comment modal
     */
    Helper.onClick('close', function () {
        Helper.hide('rating-modal');

        /**
         * Reset email/comment/rating
         */
        ratingComment.innerHTML = '';
        Helper.setValue('rate-email', '');
        Helper.setValue('rate-comment', '');
    });

    /*
    Helper.onSelect('rate-rating', function() {
        console.log(this.value);
    });
    */
   
    /**
     * Listen for click on button#rate-add-button
     */
    Helper.onClick('rate-add-button', function () {
        /**
         * Validate email, comment & rating
         */
        if (Helper.getValue('rate-email') &&
                Helper.getValue('rate-comment').length > 10 &&
                Helper.getValue('rate-comment').length < 100 &&
                Helper.getValue('rate-rating') != 0) {
            let xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    alert(this.responseText);
                    // Reload page after sent rating
                    location.reload();
                }
            };
            let url = "inc/service2.php";
            let param = {};
            param._action = "RatingSet";
            param.phone_id = phoneId;
            param.email = Helper.getValue('rate-email');
            param.comment = Helper.getValue('rate-comment');
            param.rating = Helper.getValue('rate-rating');
            xhttp.open("POST", url, true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            let jsonParam = JSON.stringify(param)
            xhttp.send(jsonParam);
        }
    });
}

/**
 * 
 * @type XMLHttpRequest
 */
let xhttp = new XMLHttpRequest();

/**
 * Load initial model list
 * @returns {undefined}
 */
xhttp.onreadystatechange = function () {
    let brands = [];
    if (this.readyState == 4 && this.status == 200) {
        let phoneObj = JSON.parse(this.responseText);
        for (let i = 0; i < phoneObj.length; i++) {
            let exist = false;
            for (let j = 0; j < brands.length; j++) {
                if (phoneObj[i].brand === brands[j]) {
                    exist = true;
                }
            }
            if (!exist) {
                brands.push(phoneObj[i].brand);
            }
        }
        let dd = document.getElementById("select-marke");
        for (let i = 0; i < brands.length; i++) {
            let option = document.createElement("option");
            let checkbox = document.createElement('input');
            checkbox.type = "checkbox";
            checkbox.name = "select-brand";
            checkbox.value = brands[i];

            option.text = brands[i];
            dd.add(option);
        }
    }
}

xhttp.open("GET", "inc/service2.php?_action=BrandList", true);
xhttp.send();
Helper.onClick("search-button", searchProduct);
Helper.onClick("compare-button", compareProduct);
