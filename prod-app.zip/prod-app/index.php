<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Produkt Applikation</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" type="text/css" href="css/default.min.css?version=1.0.0">
        <script src="inc/helper.min.js"></script>
    </head>

    <body>
        <div id="search-container" class="container">
            <h1 class="text-primary text-center">Search products</h1>
            <div>
                <select id="select-marke" multiple>
                    <option>All</option>
                </select>
            </div>
            <div>
                <button id="search-button" class="btn btn-primary btn-lg btn-block">Search</button>
            </div>
        </div>

        <div id="result-container" class="container" style="display:none">
            <h1 class="text-primary text-center">Results</h1>
            <h5 class="text-secondary text-center">(Select up to 4 models to compare)</h5>
            <div id="result-data"></div>
            <button id="compare-button" class="btn btn-primary btn-lg btn-block">Compare</button>
        </div>

        <div id="compare-container" class="container" style="display:none">

        </div>

        <!--  -->
        <div id="product-container" class="container" style="display:none">
        </div>

        <!-- Rating/comment modal -->
        <form id="rating-modal">
            <section id="modal-content" class="input-group mb-3 modal-bg">
                <h1 id="rate-heading" class="text-white text-center"></h1>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Email   :</span>
                    </div>
                    <input class="form-control" type="email" name="rate-email" id="rate-email" placeholder="jon-doe@email.com" required />
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Comment :</span>
                    </div>
                    <textarea id="rate-comment" class="form-control" aria-label="With textarea" minlength="10" maxlength="100" required></textarea>
                </div>

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="rate-rating">Rate product:</label>
                    </div>
                    <select class="custom-select" id="rate-rating">
                        <option  value="0">Choose rating</option>
                        <option value="5" class="gold">&starf;&starf;&starf;&starf;&starf;</option>
                        <option value="4" class="gold">&starf;&starf;&starf;&starf;</option>
                        <option value="3" class="gold">&starf;&starf;&starf;</option>
                        <option value="2" class="gold">&starf;&starf;</option>
                        <option value="1" class="gold">&starf;</option>
                    </select>
                </div>
                <div class="input-group mb-12">
                    <button type="button" class="btn btn-primary" id="rate-add-button">Rate!</button>
                    <button type="button" class="btn btn-light" aria-label="Close" id="close">Close</button>
                </div>
                <div>
                    <p class="text-center text-white">By sending you agree to our license agreements.</p>
                </div>
            </section>
        </form>
        <!-- END Rating/comment modal -->

        <div class="button-container">
            <a href="http://localhost/prod-app/index.php" class="btn btn-outline-primary btn-lg btn-block" role="button" aria-pressed="true">Back to start</a>
        </div>
        <script src="inc/app.min.js"></script>
        <noscript>Your browser does not support JavaScript!</noscript>
    </body>

</html>