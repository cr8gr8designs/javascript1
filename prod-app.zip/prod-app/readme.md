﻿# Product Compare #
Filstruktur:
prod-app/ccs/default.css
prod-app/inc/app.ja
prod-app/inc/helper.js
prod-app/index.html