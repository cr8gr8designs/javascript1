﻿# Product Compare #
## File structure: ##
prod-app/ccs/default.css
prod-app/inc/app.js
prod-app/inc/helper.js
..or minified versions:
prod-app/ccs/default.min.css
prod-app/inc/app.min.js
prod-app/inc/helper.min.js

prod-app/inc/service2.php

prod-app/index.php
..or HTML document:
prod-app/index.min.html